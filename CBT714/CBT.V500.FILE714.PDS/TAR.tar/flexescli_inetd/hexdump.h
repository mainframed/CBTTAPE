#ifndef _HEXDUMP_INCLUDED
#define _HEXDUMP_INCLUDED

/* static char *hexdump_h_sccsid = "%Z% %M% %I% - %G% %U% AG CS Phoenix"; */

/***************************************************************
*  
*  Routine in hexdump.c
*     hexdump              -  dump data in side by side dump format
*  
* DESCRIPTION:
*      This routine is useful in debugging programs which use complex
*      structures.  It accepts a title, a pointer, and an length.
*      It then prints the title, and dumps the data at the pointer in
*      hex and character format.
*
* USAGE:   
*      char  header[]  = "this is the title"
*      char  a[]      = "1234567890abcdefghijklmnopqrstuvwxyz@#$";
*      int   print_addr = 1;
*
*      hexdump(stderr, header, a, sizeof(a), print_addr);
*
*      produces:
this is the title
--ADDR-----OFFSET----DATA---------------------------------------------------------------------------------------------------------
000800AC   000000   31323334 35363738 39306162 63646566 6768696A 6B6C6D6E 6F707172 73747576   * 1234567890abcdefghijklmnopqrstuv *
000800CC   000020   7778797A 40232400                                                         * wxyz.... *
*
*      print_addr = 0;
*      hexdump(stderr, header, a, sizeof(a), print_addr);
*
*      produces:
this is the title
OFFSET----DATA---------------------------------------------------------------------------------------------------------
000000   31323334 35363738 39306162 63646566 6768696A 6B6C6D6E 6F707172 73747576   * 1234567890abcdefghijklmnopqrstuv *
000020   7778797A 40232400                                                         * wxyz.... *
*
*
* For backward compatiblity, The macro hex_dump
* is defined which calls hexdump with the addr parmameter hard
* coded.
***************************************************************/

#define hex_dump(a,b,c,d)  hexdump(a,b,c,d,1)

#ifdef __STDC__
void hexdump(FILE          *ofd,          /* target stream to output to */
             const char    *header,       /* title to print             */
             const char    *line,         /* data to dump               */
             int            length,       /* length of data to dump     */
             int            print_addr);  /* flag                      */

void hexdumpEBCDIC(FILE          *ofd,          /* target stream to output to */
                   const char    *header,       /* title to print             */
                   const char    *line,         /* data to dump               */
                   int            length,       /* length of data to dump     */
                   int            print_addr);  /* flag                      */

#else
void hexdump();
void hexdumpEBCDIC();
#endif

#endif
