static char *sccsid = "%Z% %M% %I% - %G% %U% AG CS Phoenix";

/*******************************************************************
*
* MODULE: hexdump   -   dump memory in hex/char format
*
* DESCRIPTION:
*      This routine is useful in debugging programs which use complex
*      structures.  It accepts a title, a pointer, and an length.
*      It then prints the title, and dumps the data at the pointer in
*      hex and character format.
*
* COMPILATION NOTES:
*      1.  The preprocessor variable ALL_ASCII_TEXT, if defined causes any printable
*          ASCII char to be included in the text part of the side by side output.
*          The default is just alpha numerics.
*
*      2.  The preprocessor variable BYTES_PER_LINE can be used to vary the number of
*          bytes dumped on each line.  For example  -DBYTES_PER_LINE=16
*
* USAGE:   
*      char  header[]  = "this is the title"
*      char  a[]      = "1234567890abcdefghijklmnopqrstuvwxyz@#$";
*      int   print_addr = 1;
*
*      hexdump(stderr, header, a, sizeof(a));
*
*      produces:
this is the title
--ADDR-----OFFSET----DATA---------------------------------------------------------------------------------------------------------
000800AC   000000   31323334 35363738 39306162 63646566 6768696A 6B6C6D6E 6F707172 73747576   * 1234567890abcdefghijklmnopqrstuv *
000800CC   000020   7778797A 40232400                                                         * wxyz.... *
*
*      print_addr = 0;
*      hexdump(stderr, header, a, sizeof(a), print_addr);
*
*      produces:
this is the title
OFFSET----DATA---------------------------------------------------------------------------------------------------------
000000   31323334 35363738 39306162 63646566 6768696A 6B6C6D6E 6F707172 73747576   * 1234567890abcdefghijklmnopqrstuv *
000020   7778797A 40232400                                                         * wxyz.... *
*
*
* INPUT PARAMETERS: 
*    ofd    - pointer to FILE
*             The first parm is a pointer to file (FILE  *efd).  This is where
*             the output is written.  stderr is a popular value for this parm.
*    header - pointer to character
*             The second parm points to a null terminated string which is
*             printed as a title over the dumped data.  If a null string
*             is passed, the title is suppressed.
*    line   - pointer to anything
*             The address of the area to be dumped is passed as the third parm
*             to this routine.  It is treated as pointer to character during
*             processing, but that is irrelevant.
*    length - int
*             The fourth parm is the length of the data to dump in bytes.  Any
*             int will do, but sizeof  the data to dump is a very convenient
*             parm to use.
*    print_addr - int
*             The fifth parm is a flag which specfies whether to print the
*             memory addresses of the data being dumped in addition to the offsets.
*             parm to use.
*
* FUNCTIONS:
*      1.  -  Output the header if it is non-null.
*      2.  -  break the data into BYTES_PER_LINE byte pieces and output them in hex and
*             character format.  In the char format area, replace non-printable
*             characters by a dot.
*
* OUTPUTS:
*      The dumped data is written to the file passed.
*
* 
*******************************************************************/


#include <stdio.h>
#include <ctype.h>

static unsigned char etoa[256] = {
0X20, 0X01, 0X02, 0X03, 0X04, 0X05, 0X06, 0X07, 0X08, 0X09, 0X0A, 0X0B, 0X0C, 0X0D, 0X0E, 0X0F, 
0X10, 0X11, 0X12, 0X13, 0X14, 0X0A, 0X16, 0X17, 0X18, 0X19, 0X1A, 0X1B, 0X1C, 0X1D, 0X1E, 0X1F, 
0X20, 0X21, 0X22, 0X23, 0X24, 0X25, 0X26, 0X27, 0X28, 0X29, 0X2A, 0X2B, 0X2C, 0X2D, 0X2E, 0X2F, 
0X30, 0X31, 0X32, 0X33, 0X34, 0X35, 0X36, 0X37, 0X38, 0X39, 0X3A, 0X3B, 0X3C, 0X3D, 0X3E, 0X3F, 
0X20, 0X41, 0X42, 0X43, 0X44, 0X45, 0X46, 0X47, 0X48, 0X49, 0X5C, 0X2E, 0X3C, 0X28, 0X2B, 0X7C, 
0X26, 0X51, 0X52, 0X53, 0X54, 0X55, 0X56, 0X57, 0X58, 0X59, 0X21, 0X24, 0X2A, 0X29, 0X3B, 0X5E, 
0X2D, 0X2F, 0X62, 0X63, 0X64, 0X65, 0X66, 0X67, 0X68, 0X69, 0X7C, 0X2C, 0X25, 0X5F, 0X3E, 0X3F, 
0X70, 0X7E, 0X72, 0X73, 0X74, 0X75, 0X76, 0X77, 0X78, 0X60, 0X3A, 0X23, 0X40, 0X27, 0X3D, 0X22, 
0X80, 0X61, 0X62, 0X63, 0X64, 0X65, 0X66, 0X67, 0X68, 0X69, 0X8A, 0X7B, 0X8C, 0X8D, 0X8E, 0X8F, 
0X90, 0X6A, 0X6B, 0X6C, 0X6D, 0X6E, 0X6F, 0X70, 0X71, 0X72, 0X9A, 0X7D, 0X9C, 0X9D, 0X9E, 0X9F, 
0XA0, 0X7E, 0X73, 0X74, 0X75, 0X76, 0X77, 0X78, 0X79, 0X7A, 0XAA, 0XAB, 0XAC, 0X5B, 0XAE, 0XAF, 
0XB0, 0XB1, 0XB2, 0XB3, 0XB4, 0XB5, 0XB6, 0XB7, 0XB8, 0XB9, 0XBA, 0X5B, 0X5C, 0X5D, 0X5E, 0XBF, 
0X7B, 0X41, 0X42, 0X43, 0X44, 0X45, 0X46, 0X47, 0X48, 0X49, 0XCA, 0XCB, 0XCC, 0XCD, 0XCE, 0XCF, 
0X7D, 0X4A, 0X4B, 0X4C, 0X4D, 0X4E, 0X4F, 0X50, 0X51, 0X52, 0XDA, 0XDB, 0XDC, 0XDD, 0XDE, 0XDF, 
0X5C, 0XE1, 0X53, 0X54, 0X55, 0X56, 0X57, 0X58, 0X59, 0X5A, 0XEA, 0XEB, 0XEC, 0XED, 0XEE, 0XEF, 
0X30, 0X31, 0X32, 0X33, 0X34, 0X35, 0X36, 0X37, 0X38, 0X39, 0XFA, 0XFB, 0XFC, 0XFD, 0XFE, 0XFF}; 

static void _hexdump(FILE          *ofd,           /* target stream to output to */
                     const char    *header,       /* title to print             */
                     const char    *line,         /* data to dump               */
                     int            length,       /* length of data to dump     */
                     int            print_addr,   /* flag                       */
                     int            ebcdic_chars);/* flag                       */


/***************************************************************
*  
*  definition for number of bytes of dump data to put out
*  on one line.  
*  
***************************************************************/
#ifndef BYTES_PER_LINE
#define BYTES_PER_LINE  32
#endif

#ifdef __STDC__
void hexdump(FILE          *ofd,           /* target stream to output to */
             const char    *header,       /* title to print             */
             const char    *line,         /* data to dump               */
             int            length,       /* length of data to dump     */
             int            print_addr)   /* flag                       */
#else
void hexdump(ofd, header,line, length, print_addr)
FILE     *ofd;
char     *header;
char     *line;
int       length;
int       print_addr;
#endif
{
_hexdump(ofd, header,line, length, print_addr, 0);
} /* end of external hexdump */


#ifdef __STDC__
void hexdumpEBCDIC(FILE          *ofd,           /* target stream to output to */
                   const char    *header,       /* title to print             */
                   const char    *line,         /* data to dump               */
                   int            length,       /* length of data to dump     */
                   int            print_addr)   /* flag                       */
#else
void hexdumpEBCDIC(ofd, header,line, length, print_addr)
FILE     *ofd;
char     *header;
char     *line;
int       length;
int       print_addr;
#endif
{
_hexdump(ofd, header,line, length, print_addr, 1);
} /* end of external hexdumpEBCDIC */


#ifdef __STDC__
static void _hexdump(FILE          *ofd,           /* target stream to output to */
                     const char    *header,       /* title to print             */
                     const char    *line,         /* data to dump               */
                     int            length,       /* length of data to dump     */
                     int            print_addr,   /* flag                       */
                     int            ebcdic_chars) /* flag                       */
#else
static void _hexdump(ofd, header,line, length, print_addr, ebcdic_chars)
FILE     *ofd;
char     *header;
char     *line;
int       length;
int       print_addr;
int       ebcdic_chars;
#endif
{

const char   *ptr;
int           offset = 0;
int           i = 0;
int           j;
int           data_dashes;
unsigned int  tchar;
unsigned int  tcharE;
char         *b_pos;
/* note, there is some padding in the following buffers */
char          text[BYTES_PER_LINE+10];
char          buffer[(BYTES_PER_LINE*3) + 80];

/***************************************************************
*  ptr is the current place in the input string being dumped
***************************************************************/
ptr = line;

/***************************************************************
*  
*  Output the header line if it was supplied
*  
***************************************************************/

if (header[0] != '\0')
   fprintf(ofd,"%s     Decimal len = %d\n",header, length);
else
   fprintf(ofd,"Decimal len = %d\n", length);

/***************************************************************
*  
*  Output the title line above the dump
*  
***************************************************************/

data_dashes = (BYTES_PER_LINE * 3) + (BYTES_PER_LINE / 4);
b_pos = buffer;
if (print_addr)
   {
      sprintf(b_pos, "--ADDR-----OFFSET----DATA-");
      b_pos += 26;
   }
else
   {
      sprintf(b_pos, "--OFFSET----DATA-");
      b_pos += 17;
   }
for (j = 0; j < data_dashes; j++)
   *b_pos++ = '-';
*b_pos = '\0';
fprintf(ofd, "%s\n", buffer);

b_pos = buffer;

/***************************************************************
*  
*  Dump the complete lines of data
*  
***************************************************************/

while (i < length )
{
   /* every 4 bytes put in a space */
   if ( (i % 4) == 0 && i != 0)
      *b_pos++ = ' ';
   /* break lines at BYTES_PER_LINE  bytes */
   if ( (i % BYTES_PER_LINE) == 0 && i != 0)
      {
         *b_pos = '\0';
         fprintf(ofd,"%s  * %s *\n", buffer, text);
         b_pos = buffer;
      }
      

   /**************************************************
   * get one byte of the data to output.
   * if is it printable, put it in the char text.
   * if it is not printable put a dot in the text.
   ***************************************************/
   tchar = *ptr;
   tchar &= 0X000000FF;
   if (ebcdic_chars)
      {
         tcharE = etoa[tchar];
#ifdef ALL_ASCII_TEXT
         if (isprint(tcharE))
            text[i % BYTES_PER_LINE] = tcharE;
         else
            text[i % BYTES_PER_LINE] = '.';
#else
         if (isdigit(tcharE) || isalpha(tcharE))
            text[i % BYTES_PER_LINE] = tcharE;
         else
            text[i % BYTES_PER_LINE] = '.';
#endif
      }
   else
      {
#ifdef ALL_ASCII_TEXT
         if (isprint(tchar))
            text[i % BYTES_PER_LINE] = tchar;
         else
            text[i % BYTES_PER_LINE] = '.';
#else
         if (isdigit(tchar) || isalpha(tchar))
            text[i % BYTES_PER_LINE] = tchar;
         else
            text[i % BYTES_PER_LINE] = '.';
#endif
      }
   text[(i % BYTES_PER_LINE) + 1] = '\0';
    
   /* print out the address at the beginning of the line */
   if ((i % BYTES_PER_LINE) == 0)
      if (print_addr)
         {
                sprintf(b_pos, "%08X   %06X   ", ptr, offset);
                b_pos += 20; /* 8 for addr, 6 for offset, 6 for blanks */
         }
      else
         {
                sprintf(b_pos, "  %06X   ", offset);
                b_pos += 11; /* 6 for offset, 5 for blanks */
         }
    /* print out 1 byte of data in hex */
    sprintf(b_pos, "%02X", tchar);
    b_pos += 2;
    /* bump to the next byte of data, also bump the byte count */
    ptr++;
    offset++;
    i++;
} /* end of while more data */

/***************************************************************
*  
*  Dump the last line of data.  First pad it with blanks.
*  
***************************************************************/

if ((i  % BYTES_PER_LINE) != 0)
   {
      j = (BYTES_PER_LINE - (i % BYTES_PER_LINE)) * 2;
      j += (j / 8) + 1;
      for (i = 0; i < j; i++)
         *b_pos++ = ' ';
   }
else
   *b_pos++ = ' ';

*b_pos = '\0';
fprintf(ofd,"%s  * %s *\n", buffer, text);

   
}  /* end of hexdump */

