
/***********************************************************
*
*   popent  -  Open a program using a pseudo teriminal as a pipe
*              
*      This routine behaves like the system popen routine in that it starts
*      a program.  Instead of returning a stream which is open for input
*      or output, it returns a file descriptor (int) which is a pseudo terminal
*      which may be used for reading or writing.  Data written to the socket
*      goes to stdin and data read from it comes from stdout. It is expected
*      that this file descriptor will be controlled using the select
*      system call.  (see popent.h for sample).  
*
*      This routine is useful if the called program expects to be talking
*      to a terminal and behaves differently if it is not.
*
*      On some systems, when the called program terminates, you will get
*      an I/O error on the read.  You should trap sigchld and note that
*      the program has ended.
*
*         
*   Returns -1 on error, and master pty file descriptor on success.
*
* USAGE:   
*      see popens.h
*
* PARAMETERS: 
*    cmdline   - pointer to char (INPUT)
*                This is the command line to execute.
*

* FUNCTIONS:
*      1.  Open the pseudo terminal pair
*      2.  Fork a child.  The parent returns one end of the socket pair.
*      3.  Parse the command and build an argument list.
*      4.  In the child, replace stdin, stdout, and stderr with
*          the other end of the socket pair.
*      5.  exec the program
*
* RETURNED VALUE:
*      fd     -    int
*                   <0    -   Error (errno is set)
*                   >0    -   socket file descriptor
* 
****************************************************************************/

/* #define BSD_COMP */  /* get BSD compatability on Solaris */
#define itoa(v, s) ((sprintf(s, "%d", (v))), (s))
#define EOF_LINE "*** EOF ***"   /* is printed instead of '^D' */

#include <stdio.h>          /* usr/include/stdio.h      */ 
#include <string.h>         /* usr/include/strings.h    */ 
#include <errno.h>          /* usr/include/errno.h      */ 
#include <limits.h>         /* usr/include/limits.h     */ 
#include <signal.h>

#ifndef NSIG
#define NSIG 256
#endif
#include <ctype.h>
#include <fcntl.h>
#include <pwd.h>

/* moved 6/19/2001 for HP/UX 11 */
#if defined(_INCLUDE_HPUX_SOURCE) || defined(solaris) || defined(linux)
#define  SYS5  1  
#else
#define _BSD   1   /* to get BSD stuff included on Apollo */
#endif

#define _NO_PROTO    /* DEC DEPRIVATION */
#include <sys/wait.h>
#undef  _NO_PROTO

#ifdef FREEBSD
#define USE_OLD_TTY
#  include <sys/ttydev.h>
#undef USE_OLD_TTY
#include <sys/ioctl_compat.h>
#include <sys/ttydefaults.h>
#ifndef O_EVENP
#  define O_EVENP EVENP
#  define O_ODDP  ODDP
#  define O_TAB1  TAB1
#  define O_TAB2  TAB2
#endif
/* #include <sys/termios.h> */
#endif /* freebsd */

#if defined(__alpha) || defined(ultrix)
#define DECBOX
#endif

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/file.h>
#ifdef solaris
#include <unistd.h>
#endif

#ifdef linux
#include <unistd.h>
#include <sgtty.h>
#include <rpcsvc/rex.h>
#define O_RAW RAW
#define O_XTABS XTABS
#define O_ECHO ECHO
#define O_CRMOD CRMOD
#define TIOCGETP TIOCGETD
#define TIOCSETP TIOCSETD
#endif

#ifndef solaris
#include <sys/ioctl.h>   /* /usr/include/sys/ioctl.h  */
#endif

#include <sys/socket.h>    /* /bsd4.3/usr/include/sys/socket.h  */
#include <sys/time.h> 
#include <utmp.h>

#ifndef MAXPATHLEN
#define MAXPATHLEN	1024
#endif

#ifndef MAX_LINE
#define MAX_LINE	1024
#endif

#ifndef FOPEN_MAX
#define FOPEN_MAX   64
#endif


#ifdef SYS5 
#include <termio.h>
#include <termios.h>
#ifndef linux
#include <sys/ttold.h>
#endif

#ifdef _INCLUDE_HPUX_SOURCE
#include <sys/bsdtty.h>
#endif

#ifndef IMAXBEL
#define IMAXBEL 0
#endif

#ifndef TCGETS
#define TCGETS TCGETA
#define TCSETS TCSETA
#endif

#ifdef linux
#define USE_XOPEN 1
#define USE_XOPEN_EXTENDED 1
#define USE_GNU 1
extern char *ptsname (int __fd) __THROW;
#endif


#include <stdlib.h>

#ifdef _INCLUDE_HPUX_SOURCE
#include <sys/ptyio.h>
#endif

/* #include <codelibs/ptyopen.h> OLD HP */

#endif  /* HPSUX */ /******************** HPSUX ****************************/

#ifndef FD_ZERO
#include <sys/select.h>    /* /usr/include/sys/select.h  */
#endif

#if defined(_INCLUDE_HPUX_SOURCE) || defined(solaris)
/*ifdef solaris RES 1/6/1999 */
#include <stropts.h>    /* for I_PUSH /usr/include/sys/stropts.h/ */
#endif


#define TTY_INT   0
#define TTY_QUIT  1
#define TTY_ERASE 2
#define TTY_KILL  3
#define TTY_EOF   4
#define TTY_START 5
#define TTY_STOP  6
#define TTY_BRK   7



#include "popent.h"

static int  tty_reset(int tty);

static void dump_ttya(int tty, char *title);
static void get_stty(void);
static void cp_stty(void);


/*
 *   Type for the set parameter sent to the select
 *   system call.  HP requires a funny type compared
 *   to everyone else.
 */

#if defined(_INCLUDE_HPUX_SOURCE) && !defined(_XOPEN_SOURCE_EXTENDED)
#define HT (int *)
#else
#define HT (fd_set *)
#endif




static int  char_to_argv(char     *cmd,
                         char     *args,
                         char     *dm_cmd,
                         char     *cmd_string, 
                         int      *argc,
                         char   ***argv,
                         char      escape_char);


static int  tty_getmode(int oldfd);
static int  tty_setmode(int newfd);
static int  tty_raw(int fd);
static int  pty_master(void);
static int  pty_slave(int master_pty_fd);
static char *pts_convert(char *pty);
static int  solaris_check_slave();

static int  check_slave();
static int  get_pty(void);
static int  ioctl_setup(int master_pty_fd); /* returns slave (child) file descriptor */
static int  shell_out_select(int timeout_microseconds);

char  *ttyname(int fd);
static unsigned char ce_tty_char[16]; /* was signed /9/2/93 */

static int  fds[2];
static char msg[256];

static char pty_name[32];  /* master name */
static char tty_name[32];  /* slave name  */
#ifdef solaris
static char pts_name[32];  /* pts name  */
#endif

static char intr_char[3];  /* printable interupt character (usually: ^C) */

static int chid = 0;    /* shell's (child) pid [used as fork() completion flag!] */
       int pid;         /* ceterm's pid */

int tty_fd = 0;   /* file descripter of accessible control terminal {0, 1, 2, shell }  */

void  (*state)();  /* funny declare for signal handeler temp pointer */

#ifndef True
#define True 1
#endif
#ifndef False
#define False 0
#endif

int debug = 0;
#define DEBUG16(x) {if (debug)   {x}}


#ifndef NTTYDISC
#define NTTYDISC 2
#endif

#if defined(_INCLUDE_HPUX_SOURCE) || defined(solaris) || defined(linux)
/* #ifdef solaris RES 1/6/1999 */
int slave_tty_fd = -1;
#endif

/**********************************************************************/
/*************************** MAIN *************************************/
/**********************************************************************/

int popent(char        *cmdline)   /* Command to execute  */
{

int i;
#ifndef SYS5
int ldisc = NTTYDISC;  
#endif
int rc = -1;
int lcl_argc;
int slave_pty_fd;
int master_pty_fd;

char *ptr;
char **lcl_argvp;
char *p;

DEBUG16(fprintf(stderr, "\npopent(%s):uid = %d, euid = %d\n", (cmdline ? cmdline : "<NULL>"), getuid(), geteuid());)

#ifdef solaris
if (((tty_fd = open("/dev/tty", O_RDWR, 0)) >= 0) ||
    ((tty_fd = open("/dev/console", O_RDWR, 0)) >= 0)){
       DEBUG16(dump_ttya(tty_fd, "Before fork, Open of /dev/tty or /dev/console");)
       rc = tty_getmode(tty_fd);
       close(tty_fd);
       DEBUG16(fprintf(stderr, "tty_getmode rc for /dev/[console|tty] = %d\n", rc);)
}else
       DEBUG16(fprintf(stderr, "(1)Can not open /dev/[tty/console]! (%s)\n", strerror(errno));)
#endif

if ((master_pty_fd = pty_master()) < 0){
    fprintf(stderr, "Could not open pseudo-terminal.\n");
    return(-1);
}

tty_fd = master_pty_fd; /* 7/18/94 SOLARIS SU problem */

#if defined(__alpha)
if ((tty_fd = open("/dev/console", O_RDWR)) >= 0) 
     rc = tty_getmode(tty_fd);
else
    DEBUG16(fprintf(stderr, "Can not open /dev/console (%s)\n", strerror(errno));)
#endif

if (rc < 0)
    rc = tty_getmode(tty_fd = master_pty_fd); 

#ifdef BLAH
if (rc < 0){
    if ((tty_fd = open("/dev/tty", O_RDWR, 0)) >= 0){ 
       rc = tty_getmode(tty_fd);
       close(tty_fd);
       tty_fd = master_pty_fd; /* 7/18/94 SOLARIS SU problem */
   }else
       DEBUG16(fprintf(stderr, "Can not open /dev/tty! (%s)\n", strerror(errno));)
}
#endif

if (rc < 0){
    tty_fd = 0;
    while (tty_fd < 32){
           if ((rc = tty_getmode(tty_fd)) >= 0) break;
           tty_fd++;
    }
}

if (rc < 0){ 
    DEBUG16(fprintf(stderr, "Can't get tty attributes, attempting defaults! (%s)\n", strerror(errno));)   
    tty_fd = master_pty_fd; /* try anyway */
}

DEBUG16(fprintf(stderr, "ttyfd=%d\n", tty_fd);)

get_stty();
cp_stty();

#ifdef blah
#ifdef SIGCLD           /* apollo has CLD and CHLD backwrds */
#if (SIGCLD != SIGCHLD)
signal(SIGCLD, dead_child);                               
#endif
#endif

#ifdef SIGCHLD
signal(SIGCHLD, dead_child);                              
#endif

/* signal handler used in child, signal send by parent */

#ifdef SIGTTOU
signal(SIGTTOU, dead_child); /* DEC_ULTRIX goes infinite otherwise! */                             
#endif 
#endif /* blah */

#if !defined(ultrix) && !defined(SYS5)
if (tty_raw(tty_fd) < 0){
    if (tty_raw(master_pty_fd) < 0){
        DEBUG16(sprintf(msg, "Can't set raw mode(%s))\n", strerror(errno));   
        fprintf(stderr, msg);)
    }
}
#endif

pid = getpid();

#if defined(ultrix)
slave_pty_fd = ioctl_setup(master_pty_fd); /* on all other boxes, executed in child! */
#endif

if ((chid = fork()) < 0){ 
     sprintf(msg, "Can't fork when preparing to start cmd (%s)\n", strerror(errno));   
     fprintf(stderr, msg);
     return(-1);
}
 
if (chid)
{  /***********************************************/ 

    /*
     * parent which returns to caller
     */

     DEBUG16( fprintf(stderr, " @popent parent, PID=%d, CHPID, %d\n", pid, chid);)

#ifdef SYS5
     if (tty_reset(tty_fd)) 
         if (tty_reset(master_pty_fd)){
             DEBUG16(sprintf(msg, "Can't reset tty(%s)\n", strerror(errno));   
             fprintf(stderr, msg);)
         }
#endif

    
#ifdef FIONBIO
     i = 1;
     ioctl(master_pty_fd, FIONBIO, &i);
#endif

/* #ifdef _INCLUDE_HPUX_SOURCE   */
#if defined(FIONOBLK) && defined(SYS5)
     DEBUG16(fprintf(stderr, "Gonna try FIONOBLK!\n");)   
     {int on=1;ioctl(master_pty_fd, FIONOBLK, &on);}
#endif


return(master_pty_fd);

}  /* end parent **********************************************/

/****************************************************************** 
*
*  Child (Which is the shell being invoked)
*
******************************************************************/

#ifdef linux
/* RES 12/16/2002 clear this signal right away */
#ifdef SIGCHLD
signal(SIGCHLD, SIG_DFL);                              
#endif
#endif

chid = getpid();  /* chid now has the same value in the parent and child */

DEBUG16( fprintf(stderr, " @popent child, PID=%d, CHPID, %d\n", pid, chid);)

for (i=1; i<NSIG; i++)   /* reset all signal handelers */
    signal(i, SIG_DFL);

#if !defined(ultrix)
slave_pty_fd = ioctl_setup(master_pty_fd);
#endif
DEBUG16( fprintf(stderr, " @popent child, slave_pty_fd=%d\n", slave_pty_fd);)
if (slave_pty_fd < 0)
   {
      fprintf(stderr, " @popent child, could not open slave pty (%s)\n", strerror(errno));
      exit(2);
   }


#if defined(_INCLUDE_HPUX_SOURCE) || defined(solaris)
/*ifdef solaris  RES 1/6/1999 */
close(master_pty_fd); /* makes /dev/ptmx->/dev/tty->getpass(2)->su(1) work! */
#endif


i = char_to_argv(NULL, cmdline, "popent", cmdline, &lcl_argc, &lcl_argvp, '\\' /* unix always uses backslash as an esacpe char */);
ptr = strrchr(lcl_argvp[0], '/');
strcpy(cmdline, lcl_argvp[0]);
if (ptr)
   lcl_argvp[0] = ptr + 1;

if (i < 0){
      fprintf(stderr, "Cannot paarese \"%s\"\n", cmdline);
      exit(1);
}

#ifndef SYS5
DEBUG16(
ioctl(tty_fd, TIOCGETD, (char *)&ldisc);    
fprintf(stderr, "Line discip(%d) = '%d'\n",tty_fd, ldisc);
ioctl(slave_pty_fd, TIOCGETD, (char *)&ldisc);  
fprintf(stderr, "Line discip(tty) = '%d'\n", ldisc);
)
#endif


#ifdef ultrix
   ldisc = NTTYDISC;
   DEBUG16(fprintf(stderr, "Line discip(tty)set to: '%d'\n", ldisc);)
   ioctl(slave_pty_fd, TIOCSETD, (char *)&ldisc);  /* old tty discipline */
#endif


cp_stty();

#ifdef linux
/***************************************************************
*  RES 2/22/1999
*  In Linux, make sure blocking is turned on for the shell.  
*  Otherwise, shell writes ahead and line discipine throws away
*  output.
***************************************************************/
i = fcntl(slave_pty_fd, F_GETFL);
if (i == -1)
   DEBUG16(fprintf(stderr, "Could not fcntl fd %d  in child to F_GETFL (%s)\n", slave_pty_fd, strerror(errno));)
else{
    i &= ~O_NONBLOCK;
    if (fcntl(slave_pty_fd, F_SETFL, i) == -1)
       DEBUG16(fprintf(stderr, "Could not fcntl fd %d  in child to turn off O_NONBLOCK (%s)\n", slave_pty_fd, strerror(errno));)
}
#endif

#ifdef sun
nice(1);  /* acctually helps the sun a great deal, but slows apollo a lot */
#endif

DEBUG16( 
fprintf(stderr, " Going to cmd: '%s'\n", cmdline);
for (i=0; lcl_argvp[i] ; i++)
    fprintf(stderr, " argv[%d]='%s'\n", i, lcl_argvp[i]);
)

if (getuid() && !geteuid()){
    DEBUG16(fprintf(stderr, "Setting uid to %d in child %d\n", getuid(), chid);)
    setuid(getuid());
}

DEBUG16(
fprintf(stderr, "fd[0]= open(%s)\n", tty_name);
)

close(0);     /* stdin becomes my output */
close(1);     /* stdout becomes my input */
close(2);     /* stderr become my input */

#ifdef SYS5
open(tty_name, O_RDWR); /* HPTERM */
/* open(tty_name, O_RDONLY); 7/10/97 tsim recommendataion */  /* HPTERM */
if ((dup(slave_pty_fd) != 1) || (dup(slave_pty_fd) != 2)){
#else
if ( (dup(slave_pty_fd) != 0) || (dup(slave_pty_fd) != 1) || (dup(slave_pty_fd) != 2)){
#endif
    fprintf(stderr, "Dup failed!, can not exec cmd.\n");
    exit(1);
}

sprintf(msg, "POPENT_TTY=%s", tty_name);
p = strdup(msg);
if (p)
   putenv(p);

for (i = 3; i < FOPEN_MAX; i++)
    close(i); 

execvp(cmdline, lcl_argvp); 

fprintf(stderr, "Exec failed!"); /* should never get here */
_exit(1);
return(-1); /* make lint happy */
} /* end of popent */

#ifdef blah
/****************************************************************** 
*
*  dead_child -  Routine called asynchronously by shell output
*
******************************************************************/

void dead_child(int sig)
{ 

int wpid;

int status_data;

 /*
  *  On the ibm, the signal catcher has to be reset .
  */

DEBUG16( fprintf(stderr, "@dead_child signal=%d, current pid = %d\n", sig, getpid());)

#ifdef SIGTTOU
if (sig == 22) signal(SIGTTOU, SIG_IGN); /* DEC_ULTRIX goes infinite otherwise! */                             
#endif 

#ifdef solaris
wpid = wait(&status_data);
#else
wpid = wait3(&status_data, WNOHANG, NULL);
            /* NOOP */ ;
#endif

if (!wpid)
    return;  /* false alarm! */

if (debug){
   fprintf(stderr, "Process [%d] died!, shell is:%d, signal was:%d, status:0x%08X\n", wpid, chid, sig, status_data);
#ifndef IBMRS6000
   if (wpid < 0)
      fprintf(stderr, "Wait terminated by signal (%s)\n", strerror(errno));
   else
      if (WIFEXITED(status_data))
         fprintf(stderr, "Process exited, code %d\n", WEXITSTATUS(status_data));
      else
         if (WIFSIGNALED(status_data))
            fprintf(stderr, "Process signaled, signal code %d\n", WTERMSIG(status_data));
         else
            if (WIFSTOPPED(status_data))
               fprintf(stderr, "Process stopped, signal code %d\n", WSTOPSIG(status_data));
            else
#ifdef WIFCONTINUED
               if (WIFCONTINUED(status_data))
                  fprintf(stderr, "Process continued, status = %d\n", status_data);
               else
#endif
                  fprintf(stderr, "Unknown cause of termination status = %d\n", status_data);

#ifdef WCOREDUMP
     if (WCOREDUMP(status_data))
        fprintf(stderr, "Core was dumped\n");
#endif
}
#endif

#ifdef ultrix
if ((wpid != chid) && (sig != 22) && chid){
#else
if ((wpid != chid) && chid){   /* !chid means parent did not wake up yet */
#endif
    DEBUG16( fprintf(stderr, "Something happened, but it was not shell %d dying, it was %d !\n", chid, wpid);)
    kill_unixcmd_window(0);  /* 0="Not real kill */
}else{
   DEBUG16(if (!chid) fprintf(stderr, "chid=0 assuming child died before parent returned from fork.\n");)
   kill_unixcmd_window(1);
   kill(-chid, SIGHUP);
}

}  /* dead_child() */
#endif




/****************************************************************** 
*
*  tty_getmode - Get the modes of the terminal
*
******************************************************************/

#ifdef SYS5
#if defined(solaris) || defined(linux)
static struct termios tty_termio;
static struct termios deftio;
#else
static struct termio tty_termio;
static struct termio deftio;
#endif
#else
static struct sgttyb  tty_sgttyb = {
        0, 0, 0177, CKILL, EVENP|ODDP|ECHO|XTABS|CRMOD
};
static struct tchars  tty_tchars = {
        CINTR, CQUIT, CSTART,
        CSTOP, CEOF, -1,
};
static struct ltchars tty_ltchars = {
        CSUSP, CDSUSP, CRPRNT,
        CFLUSH, CWERASE, CLNEXT
};
static struct winsize tty_winsize;
static int tty_localmode = LCRTBS|LCRTERA|LCRTKIL|LCTLECH;
static int tty_ldisc = NTTYDISC;
#endif

static int tty_getmode(int tty)
{

#ifdef SYS5

if (ioctl(tty, TCGETS, (char *) &tty_termio) < 0){
    sprintf(msg, "Can't ioctl(GETMODES-SYSV(%s))\n", strerror(errno));   
    DEBUG16(fprintf(stderr, msg);)
    return(-1);
}
                      
#define SYS5_DEFAULTS 1 /* kill this line if the next 100 lines gives trouble! */

#ifdef SYS5_DEFAULTS
#ifdef linux
   tty_termio.c_cflag &= ~(CBAUD);
#endif
	tty_termio.c_iflag = ICRNL|IXON|IMAXBEL; /* added 4/19/94 */
	tty_termio.c_oflag = OPOST|ONLCR|TAB3;
#ifdef BAUD_0
    	tty_termio.c_cflag = CS8|CREAD|PARENB|HUPCL;
#else	/* !BAUD_0 */
    	tty_termio.c_cflag = B9600|CS8|CREAD|PARENB|HUPCL;
#endif	/* !BAUD_0 */
       tty_termio.c_cflag &= ~(CLOCAL); /* from new xterm */
    	tty_termio.c_lflag = ISIG|ICANON|ECHO|ECHOE|ECHOK;
#ifndef solaris
	tty_termio.c_line = 0;
#endif
	tty_termio.c_cc[VINTR] = 0x7f;		/* DEL  */
	tty_termio.c_cc[VQUIT] = '\\' & 0x3f;	/* '^\'	*/
	tty_termio.c_cc[VERASE] = '#';		/* '#'	*/
	tty_termio.c_cc[VKILL] = '@';		/* '@'	*/
    	tty_termio.c_cc[VEOF] = 'D' & 0x3f;		/* '^D'	*/
	tty_termio.c_cc[VEOL] = '@' & 0x3f;		/* '^@'	*/
#ifdef VSWTCH
	tty_termio.c_cc[VSWTCH] = '@' & 0x3f;	/* '^@'	*/
#endif	/* VSWTCH */
	/* now, try to inherit tty settings */
	{
	    int i;

	    for (i = 0; i <= 2; i++) {
		if (ioctl (i, TCGETS, &deftio) == 0) {
		    tty_termio.c_cc[VINTR] = deftio.c_cc[VINTR];
		    tty_termio.c_cc[VQUIT] = deftio.c_cc[VQUIT];
		    tty_termio.c_cc[VERASE] = deftio.c_cc[VERASE];
		    tty_termio.c_cc[VKILL] = deftio.c_cc[VKILL];
		    tty_termio.c_cc[VEOF] = deftio.c_cc[VEOF];
		    tty_termio.c_cc[VEOL] = deftio.c_cc[VEOL];
#ifdef VSWTCH
		    tty_termio.c_cc[VSWTCH] = deftio.c_cc[VSWTCH];
#endif /* VSWTCH */
		    break;
		}                   
	    }
	}
/*	tty_termio.c_cc[VSUSP] = '\000';
	tty_termio.c_cc[VDSUSP] = '\000';
	tty_termio.c_cc[VREPRINT] = '\377';
	tty_termio.c_cc[VDISCARD] = '\377';
	tty_termio.c_cc[VWERASE] = '\377';
	tty_termio.c_cc[VLNEXT] = '\377';  */
#ifdef TIOCLSET_BLAH
	d_lmode = 0;
#endif	/* TIOCLSET */
#endif  /* macII || CRAY (SYS5_DEFAULTS) */

/* end of ifdef SYS5 */
#else

DEBUG16(fprintf(stderr, " @tty_getmode(tty=%d)\n", tty);)

if (ioctl(tty, TIOCGETP,   (char *) &tty_sgttyb) < 0){
    DEBUG16(fprintf(stderr, "Could not GETMODES(TIOCGETP)\n");)
    return(-1);
}

if (ioctl(tty, TIOCGLTC,   (char *) &tty_ltchars) < 0){
    DEBUG16(fprintf(stderr, "Could not GETMODES(TIOCGLTC)\n");)
    return(-1);
}
#ifdef TIOCSLTC_BLAH
        tty_ltchars.t_suspc = '\000';		/* t_suspc */
        tty_ltchars.t_suspc.t_dsuspc = '\000';	/* t_dsuspc */
        tty_ltchars.t_rprntc = '\377';	/* reserved...*/
        tty_ltchars.t_flushc = '\377';
        tty_ltchars.t_werasc = '\377';
        tty_ltchars.t_lnextc = '\377';
#endif	/* TIOCSLTC */

if (ioctl(tty, TIOCGETC,   (char *) &tty_tchars) < 0){
    DEBUG16(fprintf(stderr, "Could not GETMODES(TIOCGETC)\n");)
    return(-1);
}

if (ioctl(tty, TIOCLGET,   (char *) &tty_localmode) < 0){
    DEBUG16(fprintf(stderr, "Could not GETMODES(TIOCLGET)\n");)
    return(-1);
}

if (ioctl(tty, TIOCGETD,   (char *) &tty_ldisc) < 0){
    DEBUG16(fprintf(stderr, "Could not GETMODES(TIOCGETD)\n");)
    return(-1);
}

if (ioctl(tty, TIOCGWINSZ, (char *) &tty_winsize) < 0){
    DEBUG16(fprintf(stderr, "Could not GETMODES(TIOCGWINSZ)\n");)
    return(-1);
}
#endif

return(0);

} /* tty_getmode() */

/****************************************************************** 
*
*  tty_setmode - Set the mode of the terminal
*
******************************************************************/
#ifdef SYS5
/***** SYSV ******/
#ifdef linux
#define sg_flags flags
#define sg_ispeed chars[0]
#define sg_ospeed chars[1]
#endif
static int tty_setmode(int tty)
{
struct sgttyb sg;

DEBUG16(fprintf(stderr, " @tty_setmode(tty=%d)\n", tty);)
if (ioctl(tty, TCSETS, (char *) &tty_termio) < 0){    
     sprintf(msg, "Can't ioctl(TCSETS(%s))\n", strerror(errno));   
     fprintf(stderr, msg);
     return(-1);
} 

if(ioctl(tty, TIOCGETP, (char *)&sg) < 0){
     sprintf(msg, "Can't ioctl(TIOCGETP(%s))-set/modes\n", strerror(errno));   
     fprintf(stderr, msg);
     return(-1);
}

/* sg.sg_flags &= ~(ALLDELAY | XTABS | RAW); */
#ifdef linux
sg.sg_flags &= ~(O_XTABS | /* CBREAK | */ O_RAW);
#else
sg.sg_flags &= ~(IOCTYPE | O_XTABS | /* CBREAK | */ O_RAW);
#endif
sg.sg_flags |= O_ECHO | O_CRMOD;
/* make sure speed is set on pty so that editors work right*/
sg.sg_ispeed = B9600;
sg.sg_ospeed = B9600;

if (ioctl (tty, TIOCSETP, (char *)&sg) == -1){
     sprintf(msg, "Can't ioctl(TIOCSETP(%s))\n", strerror(errno));   
     fprintf(stderr, msg);   
     return(-1);
}

return(0);

} /* tty_setmode() */

#else

/***** BSD ******/
static int tty_setmode(int tty)
{

 /*
  * from xterm/main.c I don't know why 
  */

tty_tchars.t_brkc = -1;  

#ifdef TIOCSCTTY
DEBUG16(fprintf(stderr, "ioctl(TIOCSCTTY)\n");)
if (ioctl(tty, TIOCSCTTY, 0) < 0)
     DEBUG16(fprintf(stderr, "Can't ioctl(TIOCSCTTY(%s))\n", strerror(errno));)   
#endif


tty_localmode = LCRTBS|LCRTERA|LCRTKIL|LCTLECH; /* regular */

 /*
  *  set the tty characteristics
  */

tty_sgttyb.sg_flags |= CRMOD | ECHO;  /**** ^C ****/                     
tty_sgttyb.sg_flags &= ~(NOHANG | ANYP | RAW | CBREAK);

#ifdef sun
tty_sgttyb.sg_flags |= O_TAB1 | O_TAB2 | O_ODDP | O_EVENP;
tty_sgttyb.sg_ospeed = 0x0F;   /* makes '/usr/ucb/more' work */
#endif

if ((ioctl(tty, TIOCSETP,    (char *) &tty_sgttyb) < 0) ||   
    (ioctl(tty, TIOCSETC,    (char *) &tty_tchars) < 0) ||   
    (ioctl(tty, TIOCSLTC,    (char *) &tty_ltchars) < 0) ||  
    (ioctl(tty, TIOCLSET,    (char *) &tty_localmode) < 0) ||
    (ioctl(tty, TIOCSETD,    (char *) &tty_ldisc) < 0) ||    
    (ioctl(tty, TIOCSWINSZ,  (char *) &tty_winsize) < 0)){   
       sprintf(msg, "Can't ioctl(SETMODES(%s))\n", strerror(errno));   
       fprintf(stderr, msg);
       return(-1);
}

return(0);

} /* tty_setmode() */

#endif

/****************************************************************** 
*
*  tty_raw - Set to raw mode
*
******************************************************************/

#ifdef SYS5

/******* SYSV *****/

#if defined(solaris) || defined(linux)
static struct termios tty_mode;
#else
static struct termio tty_mode;
#endif

static int tty_raw(int fd)
{
#if defined(solaris) || defined(linux)
struct termios temp_mode;
#else
struct termio temp_mode;
#endif

if (ioctl(fd, TCGETS, (char *) &temp_mode) < 0){
   DEBUG16(sprintf(msg, "Can't ioctl(TCGETA(%s))\n", strerror(errno));   
           fprintf(stderr, msg);)
   return(-1);
}

tty_mode = temp_mode;

temp_mode.c_iflag = IMAXBEL; /* was 0 4/19/94 */
temp_mode.c_oflag &= ~OPOST;
temp_mode.c_lflag &= ~(ISIG | ICANON | ECHO | XCASE);

temp_mode.c_cflag &= ~(CSIZE | PARENB);
temp_mode.c_cflag |= CS8;
temp_mode.c_cc[VMIN] = 1;
temp_mode.c_cc[VTIME] = 1;

if (ioctl(fd, TCSETS, (char *) &temp_mode) < 0){
   DEBUG16(sprintf(msg, "Can't ioctl[R](TCSETS(%s))\n", strerror(errno));   
           fprintf(stderr, msg);)
   return(-1);
}

return(0);

} /* tty_raw() */

#else

/******* BSD *****/
static struct sgttyb tty_mode;

static int tty_raw(int fd)
{

static struct sgttyb temp_mode;

DEBUG16(fprintf(stderr, "tty fd[%d] set to RAW\n", fd);)   

if (ioctl(fd, TIOCGETP, (char *) &temp_mode) < 0){   
   DEBUG16(sprintf(msg, "Can't ioctl(GRAW(%s)[%d])\n", strerror(errno), fd);   
           fprintf(stderr, msg);)
   return(-1);
}

tty_mode = temp_mode;

   /*
    * from xterm/main.c
    */

temp_mode.sg_flags &= ~(ALLDELAY | XTABS | CBREAK | RAW); 
temp_mode.sg_flags |= ECHO | CRMOD;                       

temp_mode.sg_ispeed = B9600;
temp_mode.sg_ospeed = B9600;

   /*
    * Impose our views on the tty
    */

if (ioctl(fd, TIOCSETP, (char *) &temp_mode) < 0){   
    DEBUG16(sprintf(msg, "Can't ioctl(SRAW(%s)[%d])\n", strerror(errno), fd);   
            fprintf(stderr, msg);)
    return(-1);
}

return(0);

}  /* tty_raw() */

#endif
/****************************************************************** 
*
*  tty_reset - Reset from raw back to previos state CBREAK/COOKED
*
******************************************************************/

 /*ARGSUSED*/
static int tty_reset(int fd)
{

#if defined(ultrix) || defined(SYS5)
return(0);
#else

#ifdef SYS5
if (ioctl(fd, TCSETS, (char *) &tty_mode) < 0){   
#else
if (ioctl(fd, TIOCSETP, (char *) &tty_mode) < 0){   
#endif
       DEBUG16(sprintf(msg, "Can't ioctl(SRAWBII(%s)[%d])\n", strerror(errno), fd);   
               fprintf(stderr, msg);)
       return(-1);
}

DEBUG16(fprintf(stderr, "Resetting tty(%d)\n", fd);)

return(0);

#endif   /* ultrix */
} /* tty_reset() */



/****************************************************************** 
*
*  pty_master - Connect to the tty master
*
******************************************************************/

#ifdef _INCLUDE_HPUX_SOURCE
#define PTY_MASTER	"/dev/ptym/ptyxx"
/*
static char ptychar[] = "zyxwvutsrqp";
static char hexdigit[] = "fedcba9876543210";
*/
#else
#define PTY_MASTER	"/dev/ptyxx"
/*static char ptychar[] = "pqrs";*/
#endif
static char ptychar[] = "pqrs";
static char hexdigit[] = "0123456789abcdef";

static int pty_master(void)
{

int i, rc, len, master_fd;
char *ptr;

#if defined(_INCLUDE_HPUX_SOURCE) || defined(solaris) || defined(linux)

#ifdef linux
master_fd = getpt(); 
DEBUG16(fprintf(stderr, "getpt Master opened fd = %d\n", master_fd);)
if (master_fd < 0)
{
    sprintf(msg, "getpt failed (%s)\n", strerror(errno));   
    fprintf(stderr, msg);
    return(-1);
}

#else

strcpy(pty_name, "/dev/ptmx");
#ifdef sgi
strcpy(tty_name, _getpty(&master_fd, O_RDWR|O_NDELAY, 0600, 0));
strcpy(pty_name, "/dev/ptc");
DEBUG16(fprintf(stderr, "PI: getting master & slave SGI way(%s,)\n", tty_name );)
#else
master_fd = open(pty_name, O_RDWR, 0);
#endif

DEBUG16(fprintf(stderr, "Master opened (%s) fd = %d\n", pty_name, master_fd);)
if (master_fd < 0){
    sprintf(msg, "Can't open /dev/ptmx(%s)\n", strerror(errno));   
    fprintf(stderr, msg);
    return(-1);
}

#endif /* else not linux */

rc = grantpt(master_fd);
if (rc < 0)
    fprintf(stderr,  "Can't grantpt pty %s (%s)\n", pty_name, strerror(errno));   
rc = unlockpt(master_fd);
if (rc < 0)
    fprintf(stderr,  "Can't unlockpt pty %s (%s)\n", pty_name, strerror(errno));   

/*rc = ioctl(master_fd, I_PUSH, "pckt");
DEBUG16(fprintf(stderr, "Had to I_PUSH \"pckt\" RC=%d\n", rc);)*/

#if !defined(_INCLUDE_HPUX_SOURCE) && !defined(linux)
/*#ifndef _INCLUDE_HPUX_SOURCE*/
rc = ioctl(master_fd, I_FIND, "sockmod");
if (rc<0){
    rc = ioctl(master_fd, I_PUSH, "sockmod");
    DEBUG16(fprintf(stderr, "Had to I_PUSH \"sockmod\" RC=%d\n", rc);)
}
#endif
i = fcntl(master_fd, F_GETFL, 0); /* gleened out of truss of xterm */
fcntl(master_fd, F_SETFL, O_NDELAY | ((i>0) ? i : 0));

return(master_fd);
#else

/* struct stat statbuf; */

strcpy(pty_name, PTY_MASTER);

len = strlen(PTY_MASTER) -1;
for (ptr = ptychar; *ptr != 0; ptr++){
    pty_name[len-1] = *ptr;
    pty_name[len] = hexdigit[0];

    for (i=0; i<16; i++){
        pty_name[len] = hexdigit[i];
        if ((master_fd = open(pty_name, O_RDWR | O_NDELAY)) >= 0){
            DEBUG16(fprintf(stderr, "Master opened (%s) fd = %d\n", pty_name, master_fd);)
#if defined(SYS5)
            rc = chown (pty_name, getuid(), getgid());
            rc |= chmod (pty_name, 0600);
            if (rc){
                fprintf(stderr,  "Can't unlock pty %s (%s)\n", pty_name, strerror(errno));   
               /* close(master_fd); return(-1);  */
            }
#endif
#if defined(SYS5) /* && !defined(solaris) */
            return(master_fd);
#else
#ifdef solaris /* obsoleted at 2.3 */
            if (solaris_check_slave())
#else
            if (check_slave())
#endif
                return(master_fd);
            else{
                DEBUG16(fprintf(stderr, "Discarding Master since slave is incompatable!\n");)
                close(master_fd);
            }
#endif
        } /* if (open()) */
    }

} /* for */

if (i == 16)
  sprintf(msg, "All pty devices are used!");   
else
  sprintf(msg, "Can't open master tty: %s (%s)\n", pty_name, strerror(errno));   

fprintf(stderr, msg);
 
return(-1);

#endif /* HP & solaris  */

} /* pty_master() */

#ifdef solaris_obsolete

/****************************************************************** 
*
*  solaris_check_slave - Check if a viable solaris slave is available
*
******************************************************************/

static int solaris_check_slave()
{
int rc;

rc = open (pts_convert(pty_name), O_RDWR | O_NDELAY /*| O_NOCTTY*/);

DEBUG16(
   if (rc == -1)
       fprintf(stderr, "Slave is is not accessible.\n");
   else
       fprintf(stderr, "Slave is compatible.\n");
)

if (rc == -1)
   return(0);
else{
   close(rc);
   return(1);
}

} /* solaris_check_slave() */

/****************************************************************** 
*
*  pts_convert - Build a pts out of a pty
*
******************************************************************/
static char hextrans[16] = "0123456789abcdef";

static char *pts_convert(char *pty)
{
char *ptr;

strcpy(pts_name, pty);
ptr = strrchr(pts_name, '/');

if (ptr && (ptr > pts_name)){
    *(ptr+3) =  's';     /* /dev/ptsq7 */
    itoa(((*(ptr+4) - 'p') * 16) + 
         (strchr(hextrans, *(ptr+5)) - hextrans), ptr+5); /* /dev/ptsp23 */
    *(ptr+4) = '/';  /* /dev/pts/23 */
}

DEBUG16( fprintf(stderr," pts_convert[%s]\n",pts_name);) 
return(pts_name);

} /* pts_convert() */

#endif

/****************************************************************** 
*
*  check_slave - Check if a viable slave is available
*
******************************************************************/

static int check_slave()
{
int rc;

pty_name[5] = 't';
rc = access(pty_name, R_OK | W_OK);
pty_name[5] = 'p';

DEBUG16(
   if (rc)
       fprintf(stderr, "Slave is is not accessible.\n");
   else
       fprintf(stderr, "Slave is compatible.\n");
)

return(!rc); /* access backward logic! */

} /* check_slave() */

/****************************************************************** 
*
*  pty_slave - Connect to the tty slave
*
******************************************************************/

#if defined(SYS5)

/***** SYSV ******/
static int pty_slave(int master_pty_fd)
{

int rc;
int slave_fd;
char *ptr;
char *ptr1;

DEBUG16( fprintf(stderr," @pty_slave: master_pty_fd %d, ptyname(%s) ", master_pty_fd,  pty_name);) 

/*
 *  An example of a HP tty master names is:
 *  /dev/ptym/ptysb
 *  We want to change this to
 *  /dev/pty/ttysb
 *  That is, take out the m on the second qualifer 
 *  and change the pty to tty in the last qualifier.
 *
 *  for SOLARIS we go:
 *
 *         /dev/ptyp7 -> /dev/pts/7
 *         /dev/ptyq7 -> /dev/pts/23
 *         /dev/ptyr7 -> /dev/pts/39
 */

#ifndef sgi
strcpy(tty_name, pty_name);
ptr = strrchr(tty_name, '/');
#endif

#if defined(_INCLUDE_HPUX_SOURCE) || defined(solaris) || defined(linux)


#ifndef sgi

ptr = ptsname(master_pty_fd);
DEBUG16( fprintf(stderr," ptr=0x%X, ttyname(%s)\n", ptr, (ptr ? ptr : "ERROR!"));) 
if (!ptr){
   sprintf(msg, "Slave tty could not be found(%s)\n", strerror(errno));   
   fprintf(stderr, msg);
   return(-1);
 }
strcpy(tty_name, ptr);
#else    /* def sgi */
DEBUG16( fprintf(stderr,"\nSGI ttyname(%s)\n", tty_name);) 
#endif   /* else def sgi */

slave_fd = open(tty_name, O_RDWR);
if (slave_fd < 0)
    return(-1);
DEBUG16( fprintf(stderr," tty slave fd = (%d)\n", slave_fd);) 

#if !defined(sgi) && !defined(linux)
#ifdef _INCLUDE_HPUX_SOURCE
if ((ioctl(slave_fd, I_PUSH, "ptem") < 0) ||
    (ioctl(slave_fd, I_PUSH, "ldterm") < 0)){
   sprintf(msg, "Slave tty could not push streams modules(%s)\n", strerror(errno));   
   fprintf(stderr, msg);
   return(-1);
}
#else
if ((ioctl(slave_fd, I_PUSH, "ptem") < 0) ||
    (ioctl(slave_fd, I_PUSH, "ldterm") < 0) ||
    (ioctl(slave_fd, I_PUSH, "ttcompat") < 0)){
   sprintf(msg, "Slave tty could not push streams modules(%s)\n", strerror(errno));   
   fprintf(stderr, msg);
   return(-1);
}
#endif
#endif

#ifdef blah
if (ioctl (slave_fd, I_PUSH, "ttcompat") < 0) 
   DEBUG16(fprintf(stderr, "Could not I_PUSH('ttcompat'): %s\n",  strerror(errno));)
#endif

return(slave_fd);

#else

#ifdef _INCLUDE_HPUX_SOURCE
DEBUG16( fprintf(stderr," HP-UX/");) 
if (ptr && (ptr > tty_name)){
    ptr1 = ptr - 1;
    while (*ptr1)
       *ptr1++ = *ptr++;
}else{
     fprintf(stderr,  "pty_slave:  Cannot parse tty name %s\n", tty_name);
     return(-1);
}
#endif

#ifndef solaris
tty_name[strlen(tty_name)-5] = 't';  /* change pty to tty */
#endif

DEBUG16( fprintf(stderr," ttyname(%s)\n", tty_name);) 

if ((slave_fd = open (tty_name, O_RDWR | O_NDELAY /*| O_NOCTTY*/)) >= 0) {
      rc = chown(tty_name, getuid(), getgid());
      rc |= chmod(tty_name, 0600);
      if (rc){
          fprintf(stderr,  "Can't unlock tty %s (%s)\n", tty_name, strerror(errno));   
          return(-1);
      }
      DEBUG16(
         fprintf(stderr,"pty_slave: Slave opened: '%s',fd=%d\n", tty_name, slave_fd);
         ptr = (char *)ttyname(slave_fd);
         if (!ptr)
             fprintf(stderr,  "pty_slave: Can't get tty name for fd %d (%s)\n", slave_fd, strerror(errno));   
      )
      return(slave_fd);
}else
    fprintf(stderr,  "pty_slave: Can't open tty %s (%s)\n", tty_name, strerror(errno));   

return(-1);
#endif /* solaris */

} /* pty_slave() */

#else  /* BSD/SYSV */

/***** BSD ******/
static int pty_slave(int master_pty_fd)
{

int slave_fd;

pty_name[5] = 't';

if ((slave_fd = open(pty_name, O_RDWR)) < 0){
    return(-1);
}
pty_name[5] = 'p';

strcpy(tty_name, (char *)ttyname(slave_fd));
DEBUG16( fprintf(stderr,"Slave[BSD] opened: '%s' / tty:%s.\n", pty_name, tty_name);) 
return(slave_fd);

} /* pty_slave() */

#endif





#ifdef SYS5
struct sgttyb Dtty_sg;
#if defined(solaris) || defined(linux)
static struct termios Dtty_termio;
#else
static struct termio Dtty_termio;
#endif
#else
static struct sgttyb  Dtty_sgttyb; 
static struct tchars  Dtty_tchars; 
static struct ltchars Dtty_ltchars;
static struct winsize Dtty_winsize;
static int Dtty_localmode;
static int Dtty_ldisc;
#endif


/****************************************************************** 
*
*  get_stty - change the current line discpline
*             copy implies that on ultrix a copy of tty attributes should happen
*
******************************************************************/

#ifdef SYS5
#if defined(solaris) || defined(linux)
static struct termios gs_termio;
#else
static struct termio gs_termio;
#endif
#else
static struct sgttyb  gs_sgttyb = {
        0, 0, 0177, CKILL, EVENP|ODDP|ECHO|XTABS|CRMOD
};
static struct tchars  gs_tchars = {
        CINTR, CQUIT, CSTART,
        CSTOP, CEOF, -1,
};
#endif

static void get_stty(void)
{
int fd, tfd1 = 0, tfd2 = 0;
int first_pass = 1;
int rc = -1;

fd = tty_fd;

#ifdef SYS5
 fd=0; /* tty_fd is bad place to start under solaris 2.3 10/27/94 */
 ioctl(fd, TCGETS, (char *) &gs_termio);  /* 10/27/94 */
              /* was (signed char) 10/27/93 */
while(rc || (((char)gs_termio.c_cc[VEOF] <=0) || ((char)gs_termio.c_cc[VINTR]<=0) || ((char)gs_termio.c_cc[VEOF]>63) || ((char)gs_termio.c_cc[VINTR]>63))){
    rc = 0;
    if (ioctl(fd, TCGETS, (char *) &gs_termio) < 0){
        sprintf(msg, "Can't get stty info ioctl(%d, GETMODES-SYSV(%s) failed.)\n", fd, strerror(errno));   
        DEBUG16(fprintf(stderr, msg);)
        rc++;
    }
    if (fd == 32) break;
    fd++;
    if (first_pass){
        first_pass = 0;
        fd = 0;
    }
    DEBUG16(fprintf(stderr, "get_stty(%d): rc=%d, int=%d, eof=%d\n", fd, rc, gs_termio.c_cc[VINTR] ,gs_termio.c_cc[VEOF]);)
    if (fd == 3){
       tfd1 = open("/dev/tty", O_RDONLY, 0);
       tfd2 = open("/dev/console", O_RDONLY, 0);
    }
}

if (fd != 32){
    ce_tty_char[TTY_EOF] = gs_termio.c_cc[VEOF];
    ce_tty_char[TTY_INT] = gs_termio.c_cc[VINTR];
    ce_tty_char[TTY_QUIT] = gs_termio.c_cc[VQUIT];
    ce_tty_char[TTY_ERASE] = gs_termio.c_cc[VERASE];
    ce_tty_char[TTY_KILL] = gs_termio.c_cc[VKILL];
}

if ((ce_tty_char[TTY_EOF] < 1) || (ce_tty_char[TTY_EOF] > 254)) 
    ce_tty_char[TTY_EOF] = 4;  /* sane default */

if ((ce_tty_char[TTY_INT] < 1) || (ce_tty_char[TTY_INT] > 254)) 
    ce_tty_char[TTY_INT] = 3;  /* sane default */

#else

while(rc || ((signed char)gs_tchars.t_intrc<=0) || ((signed char)gs_tchars.t_eofc<=0)){
    rc = 0;

    if (ioctl(fd, TIOCGETP, (char *) &gs_sgttyb) < 0){
        rc++;
        DEBUG16(fprintf(stderr, "Could not GET_SGTTY(TIOCGETP)\n");)
    }

    if (ioctl(fd, TIOCGETC, (char *) &gs_tchars) < 0){
        rc++;
        DEBUG16(fprintf(stderr, "Could not GET_STTY(TIOCGETC)\n");)
    }
    DEBUG16(fprintf(stderr, "get_stty(%d): rc=%d, int=%d, eof=%d\n", fd, rc, gs_tchars.t_intrc, gs_tchars.t_eofc);)
    if (fd == 32) break;
    fd++;
    if (first_pass){
        first_pass = 0;
        fd = 0;
    }else
        DEBUG16(fprintf(stderr, "Attempt to get INT/EOF on fd:%d\n", fd);)
    if (fd == 3){
       tfd1 = open("/dev/tty", O_RDONLY, 0);
       tfd2 = open("/dev/console", O_RDONLY, 0);
    }
} /* while can't get tty attributes */

if (rc || (!gs_tchars.t_intrc && !gs_tchars.t_eofc)){
    ce_tty_char[TTY_INT] = 3;
    ce_tty_char[TTY_EOF] = 4;  /* at least use some sane defaults */
    DEBUG16(fprintf(stderr, "Could not get INT/EOF characters assuming 03/04\n");)
    rc == -1;
}else{
    ce_tty_char[TTY_INT] = gs_tchars.t_intrc;
    ce_tty_char[TTY_QUIT] = gs_tchars.t_quitc;
    ce_tty_char[TTY_ERASE] = gs_sgttyb.sg_erase;
    ce_tty_char[TTY_KILL] = gs_sgttyb.sg_kill;
    ce_tty_char[TTY_EOF] = gs_tchars.t_eofc;
    ce_tty_char[TTY_START] = gs_tchars.t_startc;
    ce_tty_char[TTY_STOP] = gs_tchars.t_stopc;
    ce_tty_char[TTY_BRK] = gs_tchars.t_brkc;
}

#endif

if (tfd1) close(tfd1); 
if (tfd2) close(tfd2); 

intr_char[0] = '^';
intr_char[1] =  'A' -1 + ce_tty_char[TTY_INT]; 
intr_char[2] = '\0';

DEBUG16(fprintf(stderr, "Get_stty: TTY_EOF='%2d', TTY_INT='%2d'\n", ce_tty_char[TTY_EOF] ,ce_tty_char[TTY_INT] );)

} /* get_stty() */

/****************************************************************** 
*
*  	cp_stty - copy implies that on ultrix a copy of tty attributes should happen
*            get_stty must be run first!
*
******************************************************************/

static void cp_stty(void)
{

#ifdef ultrix

DEBUG16(fprintf(stderr, "making copy of tty attributes\n");)

if (ioctl(tty_fd, TIOCSETP, (char *) &gs_sgttyb) < 0)
    DEBUG16(fprintf(stderr,"Could not CP_SGTTY(TIOCGETP)[tty_fd:%d]",tty_fd);)

if (ioctl(tty_fd, TIOCSETC, (char *) &gs_tchars) < 0)
    DEBUG16(fprintf(stderr,"Could not CP_STTY(TIOCGETC)[tty_fd:%d]", tty_fd);)

#endif   /* ultrix */

}  /* cp_stty() */





/**************************************************************/

/*************************************************************
*
* ioctl_setup()  - does the appropriate IOCTL manipulations against
*                 the psuedo tty device
*
**************************************************************/

static int ioctl_setup(int master_pty_fd)
{

struct passwd *pw;
int            fds1;

/*  
 * setsid releases makes us the session leader and gets rid of the control terminal.
 */

/* executed in parent on ultrix and solaris */

if ((fds1 = pty_slave(master_pty_fd)) < 0){
    fprintf(stderr, "Can't open slave tty: '%s' (%s)\n", tty_name, strerror(errno));   
    return(-1);
}

#ifdef solaris
return(fds1);
#else

if (tty_setmode(fds1) < 0){
    fprintf(stderr, "Can't set slave terminal modes (%s)\n", strerror(errno));   
    return(-1);
}

#ifdef blah
setpwent();  /* make sure password file is rewound, cp, processing could cause this to be needed */
if (!geteuid() && (pw = getpwuid(getuid())))
   initgroups(pw->pw_name, pw->pw_gid);
endpwent();
#endif

return(fds1);

#endif
} /* ioctl_setup() */


/*************************************************************
*
*  dump_ttya - bob's dump a sys5 tty
*
**************************************************************/

#if defined(SYS5)
static void dump_ttya(int tty, char *title)
{
#if defined(solaris) || defined(linux)
static struct termios tty_termios;
#endif
static struct termio  tty_termio;
int    i;

fprintf(stderr, "%s  ->  fd = %d\n", title, tty);

#ifdef solaris
if (ioctl(tty, TCGETS, (char *) &tty_termios) < 0)
   {
      fprintf(stderr, "Can't ioctl(TCGETS with termios (%s)), fd = %d\n", strerror(errno), tty);   
   }
else
   {
      fprintf(stderr, "TCGETS with termios, fd = %d\n", tty);
      fprintf(stderr, "%d, c_iflag  = 0x%08X\n", tty, tty_termios.c_iflag);
      fprintf(stderr, "%d, c_oflag  = 0x%08X\n", tty, tty_termios.c_oflag);
      fprintf(stderr, "%d, c_cflag  = 0x%08X\n", tty, tty_termios.c_cflag);
      fprintf(stderr, "%d, c_cc     = 0x", tty);
      for (i = 0; i < NCCS; i++)
         fprintf(stderr, "%02X", (unsigned int)tty_termios.c_cc[i]);
      fprintf(stderr, "\n\n");
   }
#endif


/* Now try TCGETA */


if (ioctl(tty, TCGETA, (char *) &tty_termio) < 0)
   {
      fprintf(stderr, "Can't ioctl(TCGETA with termio (%s)), fd = %d\n", strerror(errno), tty);   
   }
else
   {
      fprintf(stderr, "TCGETA with termio, fd = %d\n", tty);
      fprintf(stderr, "%d, c_iflag  = 0x%04X\n", tty, tty_termio.c_iflag);
      fprintf(stderr, "%d, c_oflag  = 0x%04X\n", tty, tty_termio.c_oflag);
      fprintf(stderr, "%d, c_cflag  = 0x%04X\n", tty, tty_termio.c_cflag);
      fprintf(stderr, "%d, c_lflag  = 0x%04X\n", tty, tty_termio.c_lflag);
      fprintf(stderr, "%d, c_line   = 0x%02X\n", tty, tty_termio.c_line);
      fprintf(stderr, "%d, c_cc     = 0x", tty);
      for (i = 0; i < NCC; i++)
         fprintf(stderr, "%02X", (unsigned int)tty_termio.c_cc[i]);
      fprintf(stderr, "\n\n");
   }

}  /*  dump_tty() */

#endif  /* SYS5 */



static void free_temp_args(char **argv)
{
   while(*argv)
   {
      free(*argv);
      argv++;
   }
} /* end of free_temp_args */



/*****************************************************************************

  char_to_argv -   break a char string into an argc/argv

PARAMETERS:

   1.  cmd     -  pointer to char  (INPUT)
                  This is an optional command name.  If non-null,
                  This a malloced copy of this string is put in argv[0];

   2.  args    -  pointer to char  (INPUT)
                  This is the string to be broken up into an argc/argc.
                  This string is not modified.

   3.  dm_cmd  -  pointer to char  (INPUT)
                  This is the name of the DM command being processed.
                  It is used in error messages.

   4.  cmd_string -  pointer to char  (INPUT)
                  This is the name full commmand line being processed (as in a
                  full dm command line.  It is used in error messages.

   5.  argc    -  pointer to int (OUTPUT)
                  This is the returned argc.

   6.  argv    -  pointer to pointer to pointer to char (OUTPUT)
                  The malloced argv is returned in this parm.
                  Since argv is a (char **), the place to stick the
                  (char **) is a (char ***)

FUNCTIONS:

   1.  If the command is name is passed in, malloc a copy and put in in argv[0].

   2.  Walk the input string adding elements to argv and incrementing arg.  If a
       malloc fails, free all we got and return failure.

   3.  Zero out argv[argc].

RETURNED VALUE:

   rc    -     int.
               This return code shows the success or lack of success of the parsing.
               0   -  all is ok
               -1  -  failure.  All malloced storage has been freed.

*********************************************************************************/

static int  char_to_argv(char     *cmd,
                         char     *args,
                         char     *dm_cmd,
                         char     *cmd_string, 
                         int      *argc,
                         char   ***argv,
                         char      escape_char)
{
char         *temp_argv[256];
char          temp_parm[256];
char         *p;
char         *q;
char          dlm_char;
int           done = False;

#define   AV_FIRSTCHAR        0
#define   AV_COPY             1
#define   AV_WHITESPACE       2
#define   AV_IN_STR           3
#define   AV_IN_STR_KEEPQUOTE 4
#define   AV_DONE             5
int       state = AV_FIRSTCHAR;


*argc = 0;
*argv = NULL;

if (cmd != NULL)
   {
      temp_argv[*argc] = malloc(strlen(cmd)+1);
      if (!temp_argv[*argc])
         return(-1);
      strcpy(temp_argv[*argc], cmd);
      (*argc)++;
      temp_argv[*argc] = NULL;
   }


p = args;
while ((*p == ' ') || (*p == '\t')) p++;
q = temp_parm;

while(!done)
{
   /***************************************************************
   *  For escaped characters, throw out the escape and 
   *  blindly copy the next character.
   ***************************************************************/
   if (*p == escape_char)
      {
         p++;
         if (*p)
            *q++ = *p++;
         else
            {
               done = True;
               fprintf(stderr, "(%s) Trailing escape char ignored (%s)", dm_cmd, cmd_string);
            }
      }
   else
      switch(state)
      {
      case AV_FIRSTCHAR:
         if ((*p == '\'') || (*p == '"'))
            {
               dlm_char = *p++;
               state = AV_IN_STR;
            }
         else
            if (*p)
               {
                  *q++ = *p++;
                  state = AV_COPY;
               }
            else
               done = True;
         break;

      case AV_COPY:
         if ((*p == ' ') || (*p == '\t') || (*p == '\0'))
            {
               *q = '\0';
               temp_argv[*argc] = malloc(strlen(temp_parm)+1);
               if (!temp_argv[*argc])
                  {
                     free_temp_args(temp_argv);
                     *argc = 0;
                     return(-1);
                  }
               strcpy(temp_argv[*argc], temp_parm);
               (*argc)++;
               temp_argv[*argc] = NULL; /* Make there be a null at the end */
               q = temp_parm;
               temp_parm[0] = '\0';
               if (*p)
                  {
                     state = AV_WHITESPACE;
                     p++;
                  }
               else
                  done = True;
            }
         else
            {
               if ((*p == '\'') || (*p == '"'))
                  {
                     dlm_char = *p;
                     state = AV_IN_STR_KEEPQUOTE;
                  }
               *q++ = *p++;
            }
         break;

      case AV_WHITESPACE:
         if ((*p != ' ') && (*p != '\t'))
            state = AV_FIRSTCHAR;
         else
            p++;
         break;

      case AV_IN_STR:
      case AV_IN_STR_KEEPQUOTE:
         if (*p == dlm_char)
            {
               if (state == AV_IN_STR_KEEPQUOTE)
                  *q++ = *p++;
               else
                  p++;
               state = AV_COPY;
            }
         else
            if (*p)
               *q++ = *p++;
            else
               {
                  fprintf(stderr, "(%s) command end in string (%s)", dm_cmd, cmd_string);
                  free_temp_args(temp_argv);
                  *argc = 0;
                  return(-1);
               }
         break;

      } /* end switch */

} /* end while */

if (*argc > 0)
   {
      *argv = (char **)malloc((*argc + 1) * sizeof(p));
      if (!*argv)
         {
            free_temp_args(temp_argv);
            *argc = 0;
            return(-1);
         }
      else
         memcpy((char *)*argv, (char *)temp_argv, *argc * sizeof(p));
      (*argv)[*argc] = NULL;
   }
else
   *argv = NULL; /* RES 6/22/95 Lint change */

return(0);

} /* end of char_to_argv */


