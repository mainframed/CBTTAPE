#ifndef _POPENT_INCLUDED
#define _POPENT_INCLUDED

/***************************************************************
*  
*     popent  -  Open a program using a pseudo teriminal as a pipe
*  
* DESCRIPTION:
*      This routine behaves like the system popen routine in that it starts
*      a program.  Instead of returning a stream which is open for input
*      or output, it returns a file descriptor (int) which is a socket
*      which may be used for reading or writing.  Data written to the socket
*      goes to stdin and data read from it comes from stdout. It is expected
*      that this file descriptor will be controlled using the select
*      system call.
*
* USAGE:
*      #include  "popens.h"
*      #include <sys/types.h>
*      #ifndef FD_ZERO
*      #include <sys/select.h>
*      #endif
*
*      char       cmd[512];
*      char       buff[512];
*      char       file[] = "/tmp/abc";
*      int        pgm_stdin_out_err;
*      int        pid;
*      int        maxfd;
*      int        count;
*      int        ready_for_more;
*      int        nfound;
*      fd_set                readfds;
*      fd_set                writefds;
*      struct timeval   time_out;
*      
*      sprintf(cmd, "/user/me/bin/myprogram %s", file);
*      pgm_stdin_out_err = popent(cmd);
*      if (pgm_stdin_out_err < 0){
*         perror("popens"); exit(1);
*      }
*      maxfd = pgm_stdin_out_err + 1;
*      ready_for_more = True;
*      while(True)
*      {
*      
*         FD_ZERO(&readfds);
*         FD_ZERO(&writefds);
*      
*         if (ready_for_more)
*            FD_SET(pgm_stdin_out_err, &writefds); /* data to program *
*         
*         if (eof_pgm_stdout == False)
*            FD_SET(pgm_stdin_out_err, &readfds); /* data from program *
*         
*         if (eof_pgm_stdout)
*            break;
*
*         time_out.tv_sec = 1;
*         time_out.tv_usec = 0;
*
*         if (ready_for_more)
*            while(((nfound = select(maxfd, &readfds, &writefds, NULL, NULL))) < 0)
*            {
*               fprintf(stderr, "select interupted (%s)\n", strerror(errno));
*               if (errno != EINTR)
*                  break;
*            }
*         else
*            while(((nfound = select(maxfd, &readfds, NULL, NULL, &time_out))) < 0)
*            {
*               fprintf(stderr, "select interupted (%s)\n", strerror(errno));
*               if (errno != EINTR)
*                  break;
*            }
*
*         if (nfound < 0)
*            break;
*      
*         if (fd_count == 0)
*            ready_for_more = True;
*         else
*            ready_for_more = False;
*
*         *  Check for messages from the program
*         if (FD_ISSET(pgm_stdin_out_err, &readfds))
*            {
*               count = read(pgm_stdin_out_err, buff, sizeof(buff));
*               if (count <= 0)
*                  eof_pgm_stdout = True;
*               ...
*            }
*         *  See if program is ready for more input
*         if (FD_ISSET(pgm_stdin_out_err, &writefds))
*            {
*               ...
*               count_out = writen(pgm_stdin_out_err, buff, count);
*               ...
*            }
*      } * end of while True * 
*      
*
*  NOTES
*  1.  If the invoked program closes stdin, stdout, or stderr and 
*      points them somewhere else, you are out of luck.
*
*  2.  On some systems, when the called program terminates, you get
*      an I/O error (count = -1) on others you get eof (count = 0)
*      You should trap SIGCHLD and set a flag to know when the called
*      program terminates.
*
***************************************************************/


                 
int popent(char        *cmdline);   /* Command to execute  */


#endif
