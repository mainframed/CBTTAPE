the <sources> CP01047.txt and CP00367.txt were downloaded from the url
"ftp://ftp.software.ibm.com/software/globalization/gcoc/attachments/"

and are included here ASIS under the fair use assumption


