CPtool      -   Added a ruler for a better reading of the tables
misc        -   shuffled things around in thir own directory
            -   Added the utils directrory for <common> functions
            -   moved the CPtool to its own directory
