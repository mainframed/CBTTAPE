the directory IDTFtools contains

esmcutil.cls
the ::require stuff with the utility functions subroutines used all around

unxmit.rex
a Rexx script to receive IDTF files

CPtool
a Rexx script to build the translate tables between different codepages

working on ...
xmit.rex
( the name tells )

and the <support>/<result> files for a run of CPtool for the codepages used

