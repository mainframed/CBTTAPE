README for Hercules-Cookbook

Tools and Toys for :

Hercules

Mac OS X / Linux

Open Object Rexx

TSO Rexx and ISPF

MVS

the REXX scripts were developed using Open Object REXX ( the current SVN )
and tested under Snow Leopard, Mountain Lion, CENTOS 6.3, CENTOS 6.4

Snow Leopard and CENTOS 6.3 are no longer supported



