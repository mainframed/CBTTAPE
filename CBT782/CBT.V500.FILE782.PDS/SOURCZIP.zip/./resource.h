//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by AWSBrowse.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_PROGRESS                    102
#define IDS_PROGRESS_CAPTION            103
#define IDR_MAINFRAME                   128
#define IDR_AWSBROWSEDOC                129
#define IDD_MY_FIND_DIALOG              131
#define IDD_SETTINGS_DIALOG             133
#define IDR_LVRCLICK_MENU               134
#define IDD_BLOCKINFO_DIALOG            135
#define IDR_DUMMYCMDS_MENU              136
#define IDI_ICONS1                      144
#define IDI_ICONS2                      145
#define IDI_ICONS3                      146
#define IDI_ICONS4                      147
#define IDD_GOTO_DIALOG                 150
#define IDC_MY_HEX_EDIT_CONTROL         1001
#define IDC_COPYRIGHT_COMPANY_STATIC    1002
#define IDC_CONTACT_EMAIL_STATIC        1003
#define IDC_PROGDLG_PROGRESS            1003
#define IDC_PRODUCT_VERSION_STATIC      1004
#define IDC_PROGDLG_PERCENT             1004
#define IDC_FINDWHAT_COMBOBOX           1008
#define IDC_UPDOWN_RADIO_BUTTON_GROUP   1011
#define IDC_RADIO2                      1012
#define IDC_DOWN_RADIO_BUTTON           1012
#define IDC_WHOLEWORD_CHECKBOX          1013
#define IDC_MATCHCASE_CHECKBOX          1014
#define IDC_BPG_EDIT                    1018
#define IDC_BPR_EDIT                    1019
#define IDC_BPG_SPINNER                 1020
#define IDC_BPR_SPINNER                 1021
#define IDC_DYN_CHECKBOX                1022
#define IDC_FORMAT_RADIOBUTTON_GROUP    1023
#define IDC_EBCDIC_RADIOBUTTON          1024
#define IDC_HEX_CHECKBOX                1025
#define IDC_TEXT_RECLEN_EDIT            1025
#define IDC_DETAILS_EDIT                1026
#define IDC_RECLEN_SPINNER              1026
#define IDC_WHERE_RADIO_BUTTON_GROUP    1027
#define IDC_FILE_RADIO_BUTTON           1028
#define IDC_TAPE_RADIO_BUTTON           1029
#define IDC_FILENAMES_COMBOBOX          1030
#define IDC_BUTTON2                     1032
#define ID_EDIT_EBCDICMODE              32773
#define ID_EDIT_ASCIIMODE               32774
#define ID_VIEW_ASCIIMODE               32775
#define ID_VIEW_ASCII                   32776
#define ID_VIEW_EBCDIC                  32777
#define ID_EDIT_FINDNEXT                32778
#define ID_EDIT_FINDPREVIOUS            32779
#define ID_EDIT_HEXAREA                 32780
#define ID_EDIT_TEXTAREA                32781
#define ID_EDIT_NEXTBLOCK               32791
#define ID_EDIT_PREVIOUSBLOCK           32792
#define ID_EDIT_NEXTFILE                32793
#define ID_EDIT_PREVIOUSFILE            32794
#define ID_HELP_DLLVERSIONINFORMATION   32798
#define ID_REGULAREXPRESSIONS_ANYCHARACTER 32799
#define ID_VIEW_SETTINGS                32803
#define ID_VIEW_DISPLAYFONT             32809
#define ID_VIEW_PRINTFONT               32810
#define ID_VIEW_DISPLAYFORMAT           32811
#define ID_VIEW_PRINTERFONT             32813
#define ID_LVRCLICK_FOO                 32814
#define ID_LVRCLICK_INFO                32816
#define ID_VIEW_ONLYTEXTNOHEX           32817
#define ID_VIEW_SHOWHEXDATA             32819
#define ID_VIEW_SHOWHEX                 32820
#define ID_VIEW_TOGGLEHEX               32821
#define ID_VIEW_HEX                     32822
#define ID_VIEW_TEXT                    32825
#define ID_VIEW_TEXTONLY                32826
#define ID_VIEW_BOTH                    32827
#define ID_FILE_CLOSE32828              32828
#define ID_FILE_MYCLOSE                 32829
#define ID_VIEW_STATISTICS              32830
#define ID_EDIT_GOTO                    32831

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        152
#define _APS_NEXT_COMMAND_VALUE         32838
#define _APS_NEXT_CONTROL_VALUE         1033
#define _APS_NEXT_SYMED_VALUE           116
#endif
#endif
